import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import java.util.HashMap;
import java.util.UUID; 
import java.util.Iterator; 
import java.util.List; 
import java.lang.Thread;
import java.lang.String;
import java.lang.Integer;
import com.sap.it.api.mapping.*;
import groovy.xml.XmlUtil;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;

import java.nio.charset.StandardCharsets

import java.util.Base64; 
import org.json.JSONObject; 
import org.json.JSONArray;
import org.json.JSONException; 
import javax.ws.rs.core.MediaType;

def Message mapIBPtoSnow(Message message) {
    def body = message.getBody(java.io.Reader);
    def input = new JsonSlurper().parse(body);
    def properties = message.getProperties(); 
    def headers    = message.getHeaders();
    
    try{
        JSONArray results_array = new JSONArray();  
        def count = 1;
        JSONArray valueJSONArray = input.get("IBPReadKeyFigures").get("item");
        if(valueJSONArray.length() > 0) {
            
            def ibp_data = valueJSONArray.collect{[
                "PRODUCT" : it.PRDID,
                "CUSTOMER" : it.CUSTID,
                "LOCATION" : it.LOCID,
                "UNITS" : it.UOMID,
                "COMMENTS" : "From IBP - Count",
                "CONSDEMAND" : it.ACTUALSQTY as BigDecimal,
                "KEYFIGUREDATE" : it.TSTFR
                ]
            }
            
            def builder = new JsonBuilder();
            def result_array_data = []
            
            Integer counterValue = message.getProperty('OverallLogCounter') as Integer ?:0;
            counterValue = counterValue + 1;
            
            def root = builder ibp_data
        	
        	def prettyBody = builder.toPrettyString();
    	    long len = prettyBody.getBytes().length; 
        	String payloadSize = len.toString(); 
        	
        	// CLEAR and SET HTTP HEaders 
        	message.setHeader("Content-Length", payloadSize); 
        	
        	message.setBody(prettyBody);
        	
        } 
     

    // Replace CR and LF with a space - TODO
    def FetchMessages = message.getHeader("FetchMessages", java.lang.String).replace("\r", " ").replace("\n", " ");
    def IBPReadRequestsResults = message.getHeader("IBPReadRequestsResults", java.lang.String).replace("\r", " ").replace("\n", " ");

    message.setHeader("FetchMessages", FetchMessages);
    message.setHeader("IBPReadRequestsResults", IBPReadRequestsResults);
    
        
    } catch (JSONException e) { 
		message.setBody(e);
	}
    return message;
}