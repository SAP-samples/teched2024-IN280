/*
    The integration developer needs to create the method processData 
    This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
    which includes helper methods useful for the content developer:
    The methods available are:
    public java.lang.Object getBody()
    public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
    public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import java.util.HashMap;
import java.util.UUID; 
import java.util.Iterator; 
import java.util.List; 
import java.lang.Thread;
import java.lang.String;
import java.lang.Integer;
import com.sap.it.api.mapping.*;
import groovy.xml.XmlUtil;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;

import java.nio.charset.StandardCharsets

import java.util.Base64; 
import org.json.JSONObject; 
import org.json.JSONArray;
import org.json.JSONException; 
import javax.ws.rs.core.MediaType;

def Message processData(Message message) {
       //Body 
       def body = message.getBody();
       message.setBody(body + "Body is modified");
       //Headers 
       def map = message.getHeaders();
       def value = map.get("oldHeader");
       message.setHeader("oldHeader", value + "modified");
       message.setHeader("newHeader", "newHeader");
       //Properties 
       map = message.getProperties();
       value = map.get("oldProperty");
       message.setProperty("oldProperty", value + "modified");
       message.setProperty("newProperty", "newProperty");
       return message;
}


def Message getTransactionID(Message message) {
    
    
    def body=message.getBody(); 
    def ibpTransactionID = "";
    byte[] responseBody = body.getBytes();;

    try {
		JSONObject extractJSON =new JSONObject(new String(responseBody));

		JSONObject contentJSONObject = extractJSON.getJSONObject("content");

		if(contentJSONObject.length() > 0){
			JSONObject propertiesJSONObject = extractJSON.contentJSONObject("content");
			ibpTransactionID = (String)propertiesJSONObject.get("Value");  
			
			message.setProperty("ibpTransactionID", ibpTransactionID); 
		}   
	    
		message.setBody(extractJSON);
	} catch (JSONException e) { 
		message.setBody(e);
	}
    return message;
}


def Message handleRequestToRead(Message message) {
    def body = message.getBody(java.io.Reader);
    def input = new JsonSlurper().parse(body);
    
    // Snowflake connection details
    message.setHeader("SFCredentials", input.SFCredentials);
    message.setHeader("SFAddress", input.SFAddress);
    message.setHeader("SFDatabase", input.SFDatabase);    
    message.setHeader("SFSchema", input.SFSchema);
    message.setHeader("SFWarehouse", input.SFWarehouse); 
    message.setHeader("SFTable", input.SFTable);
    
    // SAP IBP Connection details
    message.setHeader("IBPDestination", input.IBPDestination); 
    
    // This is new  
    message.setHeader("DestinationforSAPIBP", input.IBPDestination); 
    message.setHeader("IBPQueryTypeOfData", input.IBPQueryTypeOfData); 
    message.setHeader("IBPFields", input.IBPFields); 
    message.setHeader("IBPQueryTimeAggregationLevel", input.IBPQueryTimeAggregationLevel);
    message.setHeader("IBPBatchKey", input.IBPBatchKey);
    message.setHeader("iFlowId", "Snow_IBP_Write");
    message.setHeader("IBPPlanningArea", input.IBPPlanningArea); 
    message.setHeader("IBPPackageSizeInRows", input.IBPPackageSizeInRows);
    
    message = createGuid(message);
    
    return message;
}

def Message mapIBPtoSnow(Message message) {
    def body = message.getBody(java.io.Reader);
    try{
        
        def input = new JsonSlurper().parse(body);
        JSONArray results_array = new JSONArray();  
        def count = 1;
        JSONArray valueJSONArray = input.get("IBPReadKeyFigures").get("item");
        if(valueJSONArray.length() > 0) {
            for (item in valueJSONArray) {
                count += 1;
                 JSONObject recordObject = new JSONObject();
                 recordObject.put("PRODUCT", item.PRDID);
                 recordObject.put("CUSTOMER", item.CUSTID);
                 recordObject.put("LOCATION", item.LOCID);
                 recordObject.put("UNITS", item.UOMID);
                 recordObject.put("COMMENTS", "From IBP - Count - " + count as String);
                 recordObject.put("CONSDEMAND", item.CONSENSUSDEMANDQTY as Integer);
                 results_array.put(recordObject);
                 if(count == 10) {
                     break;
                 }
            }
            
            // Specific to Open Connectors
            ArrayList<Object> listdata = new ArrayList<Object>(); 
            for (record in results_array){
                 listdata.add(record);  
            }
             
            def prettyBody = listdata.toString() as String;
            prettyBody = prettyBody.replace("[", "");
            prettyBody = prettyBody.replace("]", "");
            long len = prettyBody.getBytes().length;
        	String payloadSize = len.toString(); 
        	
        	// CLEAR and SET HTTP HEaders 
        	
        	message.setHeader("Content-Length", payloadSize); 
    	    
        	message.setBody(prettyBody);
        } 
    } catch (JSONException e) { 
		message.setBody(e);
	}
    return message;
}

def Message formatToJSON(Message message){
    def body = message.getBody(java.io.Reader);
    try{
        def input = new JsonSlurper().parse(body); 
        
        def jsonOut = JsonOutput.toJson(input)
        
        def prettyBody = '{ \"values\" : '  + jsonOut.toString() as String ;
        prettyBody += '}';
        
        message.setBody(prettyBody); 
        
        message = createGuid(message);
        
    } catch (JSONException e) { 
		message.setBody(e);
	}
    return message;
}

def Message createGuid(Message message) {
    String guid = java.util.UUID.randomUUID(); 
    guid = guid.replace("-","").toLowerCase();
    
    message.setHeader("iFlowId", "Snow_IBP_Write");
    
    message.setProperty("IBPGuid", guid);
    
    return message;
}


def Message logIBPOutput(Message message) {
    message = logMessage("IBP Output", message);
    return message;
}


def Message logSnowflakeInput(Message message) {
    message = logMessage("Snow Input", message);
    return message;
}



def Message logSnowflakeOutput(Message message) {
    message = logMessage("Snow Output", message);
    return message;
}


def Message logMessage(java.lang.String fileName, Message message) {
    def body = message.getBody(java.lang.String);
    def messageLog = messageLogFactory.getMessageLog(message);
    def counter = getCounter(fileName + 'Counter',message).padLeft(3,' ');
    def logCounter = getCounter('OverallLogCounter',message).padLeft(4,' ');
    if(messageLog != null){
        messageLog.addAttachmentAsString(logCounter + " " + fileName + counter, body, "text/plain");
    };

    return message;
}


def String getCounter(String counterName,Message message) {
    Integer counterValue = message.getProperty(counterName) as Integer ?:0;
    counterValue = counterValue + 1;
    message.setProperty(counterName,counterValue);
    return counterValue;
}

def Message logEnvironment(java.lang.String fileName, String dataToLog, Message message) {

    def messageLog = messageLogFactory.getMessageLog(message);
    def counter = getCounter(fileName + 'Counter',message).padLeft(3,' ');
    def logCounter = getCounter('OverallLogCounter',message).padLeft(4,' ');
    if(messageLog != null){
        messageLog.addAttachmentAsString(logCounter + " head " + fileName + counter, dataToLog, "text/plain");

    };

    return message;
}

def Message printStringStatement(String dataToLog, message) {
    message = logEnvironment("PRINTLN ", dataToLog, message);
    return message;
}



def Message catch_camels(Message message){

    def map  = message.getProperties();
    def ex   = map.get("CamelExceptionCaught");
    def exceptionText;

    if (ex != null)
    {
        exceptionText    = ex.getMessage();
        def messageLog   = messageLogFactory.getMessageLog(message);
        messageLog.addAttachmentAsString("Exception", exceptionText,"application/text");

        // copy the http error response body as a property
        message.setProperty("http.statusCode", message.getHeaders().get("CamelHttpResponseCode").toString());

        try {

            def mp = [
                    "IBP Host" :  message.getHeaders().get('IBPDestination').toString(),
                    "Snowflake" :  message.getHeaders().get('SFResource').toString(),
                    "Status" : "error",
                    "stepStatus" : "error", 
                    "Message" :  exceptionText
            ];

            def ibpCommitStatus = new JSONObject(mp).toString();

            message.setProperty("http.response", ibpCommitStatus);

            message.setBody(ibpCommitStatus);

        } catch (JSONException e) {
            message.setBody(e);
        }
    }
    return message;
}

