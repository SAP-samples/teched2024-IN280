/*
    The integration developer needs to create the method processData 
    This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
    which includes helper methods useful for the content developer:
    The methods available are:
    public java.lang.Object getBody()
    public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
    public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import java.util.HashMap;
import java.util.UUID; 
import java.util.Iterator; 
import java.util.List; 
import java.lang.Thread;
import java.lang.String;
import java.lang.Integer;
import com.sap.it.api.mapping.*;
import groovy.xml.XmlUtil;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;

import java.nio.charset.StandardCharsets

import java.util.Base64; 
import org.json.JSONObject; 
import org.json.JSONArray;
import org.json.JSONException; 
import javax.ws.rs.core.MediaType;

def Message processData(Message message) {
       //Body 
       def body = message.getBody();
       message.setBody(body + "Body is modified");
       //Headers 
       def map = message.getHeaders();
       def value = map.get("oldHeader");
       message.setHeader("oldHeader", value + "modified");
       message.setHeader("newHeader", "newHeader");
       //Properties 
       map = message.getProperties();
       value = map.get("oldProperty");
       message.setProperty("oldProperty", value + "modified");
       message.setProperty("newProperty", "newProperty");
       return message;
}



def Message logSnowflakeOutput(Message message) {
    message = logMessage("Snow out", message);
    return message;
} 

def Message handleRequestToRead(Message message) {
    def body = message.getBody(java.io.Reader);
    def input = new JsonSlurper().parse(body);  
    
    // AWS S3 connection details
    message.setHeader("AWSBucketName", input.AWSBucketName);
    message.setHeader("AWSAccessKeyName", input.AWSAccessKeyName);
    message.setHeader("AWSSecretKeyName", input.AWSSecretKeyName);    
    message.setHeader("AWSDirectory", input.AWSDirectory);
    message.setHeader("AWSFile", input.AWSFile); 
    
    // Snowflake connection details
    message.setHeader("SFCredentials", input.SFCredentials);
    message.setHeader("SFAddress", input.SFAddress);
    message.setHeader("SFDatabase", input.SFDatabase);    
    message.setHeader("SFSchema", input.SFSchema);
    message.setHeader("SFWarehouse", input.SFWarehouse); 
    message.setHeader("SFTable", input.SFTable);
    message.setHeader("SFStageName", input.SFStageName);
    
    // SAP IBP Connection details
    message.setHeader("IBPDestination", input.IBPDestination); 
    // This is new  
    message.setHeader("DestinationforSAPIBP", input.IBPDestination);  
    message.setHeader("IBPQueryOffset", '0');
    message.setHeader("IBPQueryOrderBy", input.IBPQueryOrderBy);
    message.setHeader("IBPQuerySelect", input.IBPQuerySelect);
    message.setHeader("IBPQueryFilterString", input.IBPQueryFilterString);
    message.setHeader("IBPQueryKey1", "Snow_IBP_Read");
    message.setHeader("IBPQueryOffset1", input.IBPQueryOffset1);
    message.setHeader("IBPQueryTypeOfData", input.IBPQueryTypeOfData); 
    message.setHeader("IBPFields", input.IBPFields); 
    message.setHeader("IBPQueryTimeAggregationLevel", input.IBPQueryTimeAggregationLevel);
    message.setHeader("IBPBatchKey", "Snow_IBP_Read");
    message.setHeader("iFlowId", "Snow_IBP_Read");
    message.setHeader("IBPPlanningArea", input.IBPPlanningArea); 
    message.setHeader("IBPReadPlanningArea", input.IBPPlanningArea);
    message.setHeader("IBPPackageSizeInRows", input.IBPPackageSizeInRows);
    
    message = createGuid(message);
    
    return message;
} 

def Message logIBPOutput(Message message) {
    message = logMessage("IBP ee Output", message);
    return message;
}

def Message createGuid(Message message) {
    String guid = java.util.UUID.randomUUID(); 
    guid = guid.replace("-","").toLowerCase();
    message.setProperty("IBPGuid", guid);
    return message;
} 

def Message logMessage(java.lang.String fileName, Message message) {
    def body = message.getBody(java.lang.String);
    def messageLog = messageLogFactory.getMessageLog(message);
    def counter = getCounter(fileName + 'Counter',message).padLeft(3,' ');
    def logCounter = getCounter('OverallLogCounter',message).padLeft(4,' ');
    if(messageLog != null){
        messageLog.addAttachmentAsString(logCounter + " " + fileName + counter, body, "text/plain");
    };

    return message;
}


def String getCounter(String counterName,Message message) {
    Integer counterValue = message.getProperty(counterName) as Integer ?:0;
    counterValue = counterValue + 1;
    message.setProperty(counterName,counterValue);
    return counterValue;
}

def Message logEnvironment(java.lang.String fileName, String dataToLog, Message message) {

    def messageLog = messageLogFactory.getMessageLog(message);
    def counter = getCounter(fileName + 'Counter',message).padLeft(3,' ');
    def logCounter = getCounter('OverallLogCounter',message).padLeft(4,' ');
    if(messageLog != null){
        messageLog.addAttachmentAsString(logCounter + " head " + fileName + counter, dataToLog, "text/plain");

    };

    return message;
}

def Message printStringStatement(String dataToLog, message) {
    message = logEnvironment("PRINTLN ", dataToLog, message);
    return message;
}

